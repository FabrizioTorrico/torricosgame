extends BaseProjectile

var applied_style = null

func _spawn_particle_effect(particle_effect:PackedScene, pos:Vector2, dir = Vector2.RIGHT):
	var obj = particle_effect.instance()
	add_child(obj)
	#print("Particle Spawn - ",obj)

	if applied_style:
		if obj.name == "colored" and not is_ghost:
			#print(applied_style)
			#particle gets style coloring. Check children for color typing
			#print("Particle Style Activated")
			var color1 = applied_style.extra_color_1
			var color2 = applied_style.extra_color_2
			
			for C in obj.get_children():
				#print ("PARTICLE CHILDREN")
				#print(C.name)
				if "1color" in C.name:
					#print(C.color)
					C.color = color1
					#print(C.color)
				if "flicker" in C.name:
					C.color_ramp.colors[0] = color1
					C.color_ramp.colors[2] = color1
					C.color_ramp.colors[4] = color1
					var col1 = color1 #keep alpha value
					col1.a = C.color_ramp.colors[5].a
					C.color_ramp.colors[5] = col1
				if "gradient" in C.name:
					C.color_ramp.colors[0] = color1
	obj.tick()
	var facing = - 1 if dir.x < 0 else 1
	obj.position = pos
	if facing < 0:
		obj.rotation = (dir * Vector2( - 1, - 1)).angle()
	else :
		obj.rotation = dir.angle()
	obj.scale.x = facing
	remove_child(obj)
	emit_signal("particle_effect_spawned", obj)
	return obj
