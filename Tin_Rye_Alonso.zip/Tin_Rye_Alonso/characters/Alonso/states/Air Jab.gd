extends CharacterState
