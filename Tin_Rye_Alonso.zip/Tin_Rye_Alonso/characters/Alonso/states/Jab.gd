extends CharacterState

